To generate a new version:
- check that make.sh variables are OK
- run make.sh
- if new location, change manually 3xx
  [well this has to be changed in make.sh and will be automatic]
- update logs.html and index.html
- apply manual part of make.sh

To put back in tests:
- update informative part of HTML files
- run make.sh with CURRENT=tests
- copy the current set
- run the following script to update HTML files
- run the manual part of make.sh to generate bench.zip
